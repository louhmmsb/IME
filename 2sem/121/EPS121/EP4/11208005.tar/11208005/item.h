/* item.h */
#include "objetos.h"


typedef CelObjeto * Item;

#include <stdio.h>
int main(void)
{
	int a[256];
	printf("%d\n", sizeof(a));
}

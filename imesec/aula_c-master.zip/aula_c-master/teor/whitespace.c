int main(void)
{
	int* x, y, z;
}

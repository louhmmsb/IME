#ifndef FREE_H
#define FREE_H

void destroy_unused_rects(void);

#endif

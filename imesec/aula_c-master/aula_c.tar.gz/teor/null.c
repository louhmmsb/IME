#include <stdlib.h>
int main(void)
{
	int *x = NULL;
	*x = 3;
	return 0;
}

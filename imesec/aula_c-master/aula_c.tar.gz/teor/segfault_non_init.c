int main(void)
{
	int *c;
	*c = 3;
	return 0;
}
